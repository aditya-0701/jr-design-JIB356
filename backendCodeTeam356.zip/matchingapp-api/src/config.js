exports.dbconfig = {
  host: 'database-2.cglfpa8mmg5n.us-east-2.rds.amazonaws.com',
  user: 'admin',
  password: 'n&fSaCwj$9^c14x',
  port: '3306',
  database: 'matchingapp',
  connectionLimit: 25
};

# Test Readme for the API

This is a test readme for the API being built to communicate with our RDS DB for the app. This will be updated shortly.
